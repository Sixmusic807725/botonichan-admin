exports.TOKEN = '';

exports.PREFIX = '';

exports.news_API = '';

exports.giphy_API = '';

exports.AME_API = '';
